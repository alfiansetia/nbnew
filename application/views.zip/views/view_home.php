<!--Slider Start-->
<div class="slider">
    <div class="slide-carousel slider-one owl-carousel">
        <?php
        foreach ($sliders as $slider) {
        ?>
            <div class="slider-item flex" style="background-image:url(<?php echo base_url(); ?>public/uploads/<?php echo $slider['photo']; ?>);">
                <div class="bg-slider"></div>
                <div class="container">
                    <div class="row">
                        <div class="<?php if ($slider['position'] == 'Left') {
                                        echo 'col-lg-6 col-md-9 col-12';
                                    } else {
                                        echo 'offset-lg-6 col-lg-6 offset-md-3 col-md-9 col-12';
                                    } ?>">
                            <div class="slider-text">

                                <?php if ($slider['heading'] != '') : ?>
                                    <div class="text-animated">
                                        <h1><?php echo $slider['heading']; ?></h1>
                                    </div>
                                <?php endif; ?>

                                <?php if ($slider['content'] != '') : ?>
                                    <div class="text-animated">
                                        <p>
                                            <?php echo nl2br($slider['content']); ?>
                                        </p>
                                    </div>
                                <?php endif; ?>


                                <?php if ($slider['button1_text'] != '' || $slider['button2_text'] != '') : ?>
                                    <div class="text-animated">

                                        <ul>
                                            <li> <button class="btn btn-primary">Shop for dog</button></li>
                                            <li> <button class="btn btn-primary">Shop for cat </button></li>

                                        </ul>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
    </div>
</div>
<!--Slider End-->

<!--About Start-->
<?php if ($page_home_lang_independent['home_welcome_status'] == 'Show') : ?>
    <div class="about-area pt_60 pb_90 mb-5">
        <div class="row">
            <div class="col-lg-4 mt_30">
                <img class="dog-image" src="<?php echo base_url(); ?>public/images/about-1.png" alt="About Photo">
            </div>
            <div class="col-lg-6 mt_30">
                <div class="about-content">
                    <div class="headline-left">
                        <h3>
                            OUR BRAND STORY
                        </h3>
                        <p>Lorem ipsum dolor sit amet consectetur. Viverra nisl lectus sit lorem maecenas viverra dignissim quam. Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-primary">More</button>
                    </div>
                    <div class="headline-right">
                        <h3>
                            VISION & MISSION </h3>
                        <p>Lorem ipsum dolor sit amet consectetur. Viverra nisl lectus sit lorem maecenas viverra dignissim quam. Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-primary">More</button>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php endif; ?>
<!--About End-->

<!--Choose-Area Start-->
<?php if ($page_home_lang_independent['home_why_choose_status'] == 'Show') : ?>
    <div class="choose-area pb_90 ">
        <div class="container mt-5">
            <div class="row">
                <div class="col-12">
                    <div class="headline">
                        <h2>WHY CHOOSE US</h2>
                        <h3>Lorem ipsum dolor sit amet consectetur. Enim neque et sed eget tortor consequat eget cras nunc. Elit at neque tincidunt ac pulvinar viverra ac sit justo.</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 mt_30">
                    <img class="choose-image" src="<?php echo base_url(); ?>public/images/why-choose.png" alt="About Photo">
                </div>
                <div class="col-lg-6 mt_30 choose-content">
                    <div class="d-flex align-item-center">
                        <img src="<?php echo base_url(); ?>public/images/why-1.png" alt="Why Choose Us" class="why-img">
                        <div class="ml-2">
                            <h3>Gluten Free</h3>
                            <p>Lorem ipsum dolor sit amet consectetur. Tortor malesuada turpis tempor feugiat consequat. Dolor at pulvinar amet pellentesque eleifend at dui viverra at.</p>
                        </div>
                    </div>
                    <div class="d-flex mt-3">
                        <img src="<?php echo base_url(); ?>public/images/why-2.png" alt="Why Choose Us" class="why-img">
                        <div class="ml-2">
                            <h3>Quality Standards</h3>
                            <p>Lorem ipsum dolor sit amet consectetur. Tortor malesuada turpis tempor feugiat consequat. Dolor at pulvinar amet pellentesque eleifend at dui viverra at.</p>
                        </div>
                    </div>
                    <div class="d-flex mt-3">
                        <img src="<?php echo base_url(); ?>public/images/why-3.png" alt="Why Choose Us" class="why-img">
                        <div class="ml-2">
                            <h3>Hypoallergenic</h3>
                            <p>Lorem ipsum dolor sit amet consectetur. Tortor malesuada turpis tempor feugiat consequat. Dolor at pulvinar amet pellentesque eleifend at dui viverra at.</p>
                        </div>
                    </div>
                    <div class="d-flex mt-3">
                        <img src="<?php echo base_url(); ?>public/images/why-4.png" alt="Why Choose Us" class="why-img">
                        <div class="ml-2">
                            <h3>Healthier With Herbs</h3>
                            <p>Lorem ipsum dolor sit amet consectetur. Tortor malesuada turpis tempor feugiat consequat. Dolor at pulvinar amet pellentesque eleifend at dui viverra at.</p>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php endif; ?>
<!--Choose-Area End-->

<!--Portfolio Start-->
<?php if ($page_home_lang_independent['home_portfolio_status'] == 'Show') : ?>
    <div class="portfolio-area pt_90 ">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="headline">
                        <h2>EXPLORE OUR PRODUCT</h2>
                        <h3>Lorem ipsum dolor sit amet consectetur. Viverra nisl lectus sit lorem maecenas viverra dignissim quam. Lorem ipsum dolor sit amet consectetur.</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                
                <div class="col-12">
                    <div class="portfolio-menu">
                        <ul id="filtrnav">
                            <li class="filtr" data-filter="dog">
                                <span>
                                    <img src="<?php echo base_url(); ?>public/svg/dog-active.svg" width="20px" height="20px" alt="Why Choose Us" class="why-img">
                                </span>
                                FOR DOGS
                            </li>
                            <li class="filtr" data-filter="cat">
                                <span>
                                    <img src="<?php echo base_url(); ?>public/svg/cat.svg" width="20px" height="20px" alt="Why Choose Us" class="why-img">
                                </span>
                                FOR CATS
                            </li>
                            <li class="filtr" data-filter="vet">
                                <span>
                                    <img src="<?php echo base_url(); ?>public/svg/vet.svg" width="20px" height="20px" alt="Why Choose Us" class="why-img">
                                </span> VET EXCLUSIVE
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="row filtr-container">
                <div class="col-lg-4 col-md-6 filtr-item" data-category="dog" data-sort="Menu">
                    <div class="portfolio-group">
                        <div class="portfolio-photo" style="background-image: url(<?php echo base_url(); ?>public/images/product-1.png">
                        </div>
                        <div class="portfolio-text d-flex justify-content-between align-items-center">
                            <div class="text-start">
                                <h3 class="mb-0"><a href="">Product Name</a></h3>
                                <span style="font-size: 14px">Product Lines</span>
                            </div>
                            <div>
                                <button class="btn btn-primary">
                                    <img src="<?php echo base_url(); ?>public/svg/arrow-right.svg" width="30px" height="0px" alt="Arrow">
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 filtr-item" data-category="cat" data-sort="Menu">
                    <div class="portfolio-group">
                        <div class="portfolio-photo" style="background-image: url(<?php echo base_url(); ?>public/images/product-1.png">
                        </div>
                        <div class="portfolio-text d-flex justify-content-between align-items-center">
                            <div class="text-start">
                                <h3 class="mb-0"><a href="">Product Name</a></h3>
                                <span style="font-size: 14px">Product Lines</span>
                            </div>
                            <div>
                                <button class="btn btn-primary">
                                    <img src="<?php echo base_url(); ?>public/svg/arrow-right.svg" width="30px" height="0px" alt="Arrow">
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 filtr-item" data-category="vet" data-sort="Menu">
                    <div class="portfolio-group">
                        <div class="portfolio-photo" style="background-image: url(<?php echo base_url(); ?>public/images/product-1.png">
                        </div>
                        <div class="portfolio-text d-flex justify-content-between align-items-center">
                            <div class="text-start">
                                <h3 class="mb-0"><a href="">Product Name</a></h3>
                                <span style="font-size: 14px">Product Lines</span>
                            </div>
                            <div>
                                <button class="btn btn-primary">
                                    <img src="<?php echo base_url(); ?>public/svg/arrow-right.svg" width="30px" height="0px" alt="Arrow">
                                </button>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    <?php endif; ?>
    <!--Portfolio End-->

    <!--Testomonial-Area Start-->
    <?php if ($page_home_lang_independent['home_testimonial_status'] == 'Show') : ?>
        <div class="testimonial-area pt_90 pb_90">
            <div class="bg-testimonial"></div>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="headline hl-white">
                            <h2>WHAT THEY SAY </h2>
                            <h3>Don't just take our word for it! Read stories from our customers.</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="testimonial-carousel owl-carousel owl-carousel mt-30" data-items="1" data-slide-by="1" data-dots="true" data-dots-each="1">
                            <?php
                            foreach ($testimonials as $row) {
                            ?>
                                <div class="testimonial-item">
                                    <div>
                                        <img-comparison-slider>
                                            <img slot="first" width="100%" src="https://d1vbn70lmn1nqe.cloudfront.net/prod/wp-content/uploads/2023/10/30052917/Ini-9-Manfaat-Daun-Sembung-untuk-Kesehatan-yang-Jarang-Diketahui-.jpg.webp">
                                            <img slot="second" width="100%" src="https://awsimages.detik.net.id/community/media/visual/2023/10/17/1253663006_169.jpeg?w=1200">
                                        </img-comparison-slider>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-body">
                                        <div>
                                            <img src="<?php echo base_url(); ?>public/svg/testi-icon.svg" style="width: 80px" alt="Arrow">

                                        </div>

                                        <h4 style="font-weight: 700">Subject Line</h4>
                                        <p>Lorem ipsum dolor sit amet consectetur. Sed cursus cras etiam adipiscing diam arcu libero netus. Egestas elementum pellentesque urna dui ac.</p>
                                        <span style="font-weight:bold">Martin Luther</span>
                                        <div class="d-flex">
                                            <img src="<?php echo base_url(); ?>public/svg/star.svg" style="width: 20px" alt="Arrow">
                                            <img src="<?php echo base_url(); ?>public/svg/star.svg" style="width: 20px" alt="Arrow">
                                            <img src="<?php echo base_url(); ?>public/svg/star.svg" style="width: 20px" alt="Arrow">
                                            <img src="<?php echo base_url(); ?>public/svg/star.svg" style="width: 20px" alt="Arrow">
                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    <?php endif; ?>
    <!--Testomonial-Area End-->

    <!--Services Start-->
    <?php if ($page_home_lang_independent['home_service_status'] == 'Show') : ?>
        <div class="services-area pt_90 pb_90">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="headline d-flex align-items-center  justify-content-between">
                            <h2>PET TIPS</h2>
                            <div>
                                <button class="btn btn-primary">See all articles</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="services-item effect-item">
                            <a href="<?php echo base_url(); ?>service/view/1 ?>" class="image-effect">
                                <div class="services-photo" style="background-image: url(<?php echo base_url(); ?>public/images/tips-1.png); border-radius: 8px 8px 0px 0px"></div>
                            </a>
                            <div class="services-text">
                                <h3 class="d-flex justify-content-between">
                                    <a href="<?php echo base_url(); ?>service/view/1"> Lorem ipsum dolor sit amet consectetur.
                                    </a>
                                    <img src="<?php echo base_url(); ?>public/svg/arrow-right.svg" width="40px" height="40px" alt="Arrow">
                                </h3>

                                <div class="d-flex">
                                    <div class="button-bn">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <img src="<?php echo base_url(); ?>public/svg/calendar.svg" width="20px" height="20px" alt="Arrow">

                                            </div>
                                            <div class="ml-2">Jan 07, 2024</div>
                                        </div>
                                    </div>
                                    <div class="button-bn ml-2">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <img src="<?php echo base_url(); ?>public/svg/update.svg" width="20px" height="20px" alt="Arrow">

                                            </div>
                                            <div class="ml-2">Jan 07, 2024</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="services-item effect-item">
                            <a href="<?php echo base_url(); ?>service/view/1 ?>" class="image-effect">
                                <div class="services-photo" style="background-image: url(<?php echo base_url(); ?>public/images/tips-1.png); border-radius: 8px 8px 0px 0px"></div>
                            </a>
                            <div class="services-text">
                                <h3 class="d-flex justify-content-between">
                                    <a href="<?php echo base_url(); ?>service/view/1"> Lorem ipsum dolor sit amet consectetur.
                                    </a>
                                    <img src="<?php echo base_url(); ?>public/svg/arrow-right.svg" width="40px" height="40px" alt="Arrow">
                                </h3>

                                <div class="d-flex">
                                    <div class="button-bn">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <img src="<?php echo base_url(); ?>public/svg/calendar.svg" width="20px" height="20px" alt="Arrow">
                                            </div>
                                            <div class="ml-2">Jan 07, 2024</div>
                                        </div>
                                    </div>
                                    <div class="button-bn ml-2">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <img src="<?php echo base_url(); ?>public/svg/update.svg" width="20px" height="20px" alt="Arrow">

                                            </div>
                                            <div class="ml-2">Jan 07, 2024</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="services-item effect-item">
                            <a href="<?php echo base_url(); ?>service/view/1 ?>" class="image-effect">
                                <div class="services-photo" style="background-image: url(<?php echo base_url(); ?>public/images/tips-1.png); border-radius: 8px 8px 0px 0px"></div>
                            </a>
                            <div class="services-text">
                                <h3 class="d-flex justify-content-between">
                                    <a href="<?php echo base_url(); ?>service/view/1"> Lorem ipsum dolor sit amet consectetur.
                                    </a>
                                    <img src="<?php echo base_url(); ?>public/svg/arrow-right.svg" width="40px" height="40px" alt="Arrow">
                                </h3>

                                <div class="d-flex">
                                    <div class="button-bn">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <img src="<?php echo base_url(); ?>public/svg/calendar.svg" width="20px" height="20px" alt="Arrow">

                                            </div>
                                            <div class="ml-2">Jan 07, 2024</div>
                                        </div>
                                    </div>
                                    <div class="button-bn ml-2">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <img src="<?php echo base_url(); ?>public/svg/update.svg" width="20px" height="20px" alt="Arrow">

                                            </div>
                                            <div class="ml-2">Jan 07, 2024</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <!--Services End-->